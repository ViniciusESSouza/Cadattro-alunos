export const AlunosCadastrados = [
    {
      nome: "Henrique Alves",
      ra: "5", 
      idade: 23,
      sexo: "M",
      media: 7.2,
      resultado: "Aprovado"
    },
    {
      nome: "João Pedro",
      ra: "3", 
      sexo: "M",
      media: 4.9,
      resultado: "Reprovado"
    },
    {
      nome: "Isabela Martins",
      ra: "8", 
      idade: 18,
      sexo: "F",
      media: 6.0,
      resultado: "Aprovado"
    },
    {
      nome: "Eduarda Lima",
      ra: "1", 
      sexo: "F",
      media: 9.1,
      resultado: "Aprovado"
    },
    {
      nome: "Carla Mendes",
      ra: "2", 
      idade: 18,
      sexo: "F",
      media: 4.3,
      resultado: "Reprovado"
    },
    {
      nome: "Felipe Rocha",
      ra: "4", 
      idade: 20,
      sexo: "M",
      media: 5.5,
      resultado: "Aprovado"
    },
    {
      nome: "Ana Beatriz",
      ra: "7", 
      idade: 19,
      sexo: "F",
      media: 8.5,
      resultado: "Aprovado"
    },
    {
      nome: "Daniel Souza",
      ra: "6", 
      idade: 21,
      sexo: "M",
      media: 5.0,
      resultado: "Reprovado"
    },
    {
      nome: "Gabriela Torres",
      ra: "9", 
      idade: 19,
      sexo: "F",
      media: 3.8,
      resultado: "Reprovado"
    },
    {
      nome: "Bruno Silva",
      ra: "10", 
      idade: 20,
      sexo: "M",
      media: 6.7,
      resultado: "Aprovado"
    }
  ];